# frogie's arcade v3 portable deployable

## https://discord.com/invite/fErn6KteQn

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FFrogiesArcade%2FFrogiesArcade-v2-Portable)
<a target="_blank" href="https://app.cyclic.sh/api/app/deploy/FrogiesArcade/FrogiesArcade-v2-Portable"><img alt="Deploy to Cyclic" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/cyclic.svg"></a>
<a target="_blank" href="https://app.koyeb.com/deploy?type=git&repository=github.com/FrogiesArcade/FrogiesArcade-v2-Portable"><img alt="Deploy to Koyeb" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/koyeb.svg"></a>


## run npm i

### when it is done run node index.js
### if you have any errors just install the packages it is asking for

- any deploy service should work just fine
- this is NOT source code, it's just a proxy so that anyone can deploy
- NO STATIC DEPLOYMENTS WILL WORK, THIS IS A NODE.JS FILE!


### if you enjoy this and decide to fork it please star this respository please with a cherry on top
